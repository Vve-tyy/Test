package newsSystem;

import java.sql.*;

public class DBUtil {
  Connection conn = null;
  Statement stat = null;
  PreparedStatement ps = null;
  ResultSet rs = null;
 //建立连接
 public Connection getConn() {
	 try {
		 Class.forName("com.mysql.cj.jdbc.Driver");
		 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/periment?serverTimezone=Asia/Shanghai","root","123456");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 return conn;
 }
 //模糊查询
 public ResultSet getResult(String sql,String id) {
	 rs=null;
	 if(conn==null) {
		 conn = this.getConn();
	 }
	 try {
		ps=conn.prepareStatement(sql);
		ps.setString(1, id);
		rs=ps.executeQuery();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 return rs;
 }
//全部查询
 public ResultSet getResult(String sql) {
	 rs=null;
	 if(conn==null) {
		 conn = this.getConn();
	 }
	 try {
		stat=conn.createStatement();
		rs=stat.executeQuery(sql);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 return rs;
 }
//删除
 public void getResultDel(String sql,String id) {
		if(conn==null) {
			conn=this.getConn();
		}
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.executeUpdate();			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
//添加
 public void getResultADD(String sql,String[]args) {

		if(conn==null) {
			conn=this.getConn();
		}
		try {
			ps=conn.prepareStatement(sql);
			for(int i=0;i<args.length;i++) {
				ps.setString(i+1, args[i]);
			}
			System.out.println(ps.toString());
			ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
//编辑
public void getResultUpdata(String sql,String[]args) {

		if(conn==null) {
			conn=this.getConn();
		}
		try {
			ps=conn.prepareStatement(sql);
			for(int i=0;i<args.length;i++) {
				ps.setString(i+1, args[i]);
			}
			ps.setInt(5, Integer.valueOf(args[4]));
			System.out.println(ps.toString());
			ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
/**
 * 关闭连接并且回收资源
 */
public void release() {
	try {
		if(rs!=null)rs.close();
		if(stat!=null)stat.close();
		if(conn!=null)conn.close();
		if(ps!=null)ps.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
