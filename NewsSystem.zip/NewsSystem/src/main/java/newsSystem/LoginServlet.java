package newsSystem;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *                                             登录界面处理
 */

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(description="/LoginServlet",urlPatterns = {"/LoginServlet" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String ManageName = request.getParameter("ManageName");
		String ManagePwd = request.getParameter("ManagePwd");
		String inputError = "用户名或密码错误!";
		HttpSession session = request.getSession();
		if(ManageName.equals("lele")&&ManagePwd.equals("123456")) {		
			session.setAttribute("ManageName", ManageName);
			session.setAttribute("ManagePwd", ManagePwd);
			request.getRequestDispatcher("/jsp/Manager.jsp").forward(request, response);
		}else {
			session.setAttribute("message", inputError);
			response.sendRedirect(request.getContextPath()+"/jsp/BackManage.jsp");
			
		}
	}

}
