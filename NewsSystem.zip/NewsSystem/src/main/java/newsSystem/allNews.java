package newsSystem;

import java.io.PrintWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import newsSystem.DBUtil;
import newsSystem.News;
/**
 * Servlet implementation class allNews
 */
@WebServlet(description="/allNews",urlPatterns= {"/allNews"})
public class allNews extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public allNews() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
//		request.getRequestDispatcher("/jsp/ShowallNews.jsp").forward(request, response);
		response.setContentType("text/html;charset=utf-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		List<News> newsList = new ArrayList<>();
		try {
			DBUtil db = new DBUtil();
			Connection conn=db.getConn();
			String sql = "select * from newsdetail";
			ResultSet rs = db.getResult(sql);
			while(rs.next()) {
				News news = new News();
                news.setId(rs.getString("id"));
                news.setTitle(rs.getString("title"));               
                news.setType(rs.getString("type"));
                news.setAuthor(rs.getString("author"));
                news.setContent(rs.getString("content"));
                news.setTime(rs.getString("time"));
                newsList.add(news);
			}
			db.release();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		session.setAttribute("newsList", newsList);
		request.getRequestDispatcher("/jsp/ShowallNews.jsp").forward(request, response);
	}
		
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}
}
