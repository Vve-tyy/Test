package newsSystem;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import newsSystem.DBUtil;
import newsSystem.News;

/**
 * Servlet implementation class UpdataNewsServlet
 */
@WebServlet(description = "UpdataNewsServlet", urlPatterns = { "/UpdataNewsServlet" })
public class UpdataNewsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdataNewsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		DBUtil db=new DBUtil();
		HttpSession session = request.getSession();
		String id = (String)request.getParameter("id");
		
		String title = (String)request.getParameter("Title");
		String type = (String)request.getParameter("Type");
		String author = (String)request.getParameter("Author");
		String content = (String)request.getParameter("Content");
		
		switch(type) {
			case "金融":type = "金融";break;
			case "餐饮":type = "餐饮";break;
			case "科技":type = "科技";break;
			case "生活":type = "生活";break;
			case "娱乐":type = "娱乐";break;
			case "知识":type = "知识";break;
			default: type = "其他";
		}
		String sql = "UPDATE newsdetail SET title = ?, content = ?, author = ?, type= ? WHERE id = ?;";
		try {
			
			 db.getConn();
			 db.getResultUpdata(sql, new String[] {title, content, author, type, id});
			
			 response.sendRedirect(request.getContextPath() + "/admin/adminAllNews.jsp");
		} finally {
				db.release();
		}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
